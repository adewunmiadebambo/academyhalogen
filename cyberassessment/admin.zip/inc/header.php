<div id="header">

	<nav class="navbar navbar-fixed-top">
	
		<div class="container-fluid">
		
			<div>
				
				<div class="row">
				
					<div class="col-md-3">
						
						<span class="navbar-brand">
					
							<img src="./images/academy.jpg">
					
						</span>
						
						
					
					</div>
				
					<div class="col-md-9"><div class="col-md-8"><h1 style="text-align: center;">Management Trainee Programme in Enterprise Security Risk Management</h1></div></div>
				
				</div>
			
			</div>
		
		</div>
	
	</nav>

</div>


<!--
<div id="header">
<nav class="navbar navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>
      <li><a href="#">Page 3</a></li>
    </ul>
  </div>
</nav>
</div>
  -->