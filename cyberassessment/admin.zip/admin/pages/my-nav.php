<div class="navbar-default sidebar" role="navigation">
<div class="sidebar-nav navbar-collapse">
<ul class="nav" id="side-menu">
<li>
<a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
</li>
<li>
<a href="applicants.php"><i class="fa fa-users fa-fw"></i>Applicants</a>
</li>
<li>
<a href="change-pass.php"><i class="fa fa-unlock fa-fw"></i> Change Password</a>
</li>
<li>
<a href="logout.php"><i class="fa fa-lock fa-fw"></i> Logout</a>
</li>
</ul>
</div>
<!-- /.sidebar-collapse -->
</div>
