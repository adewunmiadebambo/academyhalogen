<?php

header('Location: pages/index.php');


?>