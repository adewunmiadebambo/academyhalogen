<?php

header('Location: landing.php');

?>