$(function() {
	
	$('.qq').hide();
	$('#section1').fadeIn(30);
	
	$('#sect1').click(function(){
		
				
		$('.qq').hide();
		$('#question1').fadeIn(30);
		
		
	});
	
	
	$('#start').click(function(){
		
		
		$('.qq').hide();
		
		$('#question2').fadeIn(30);
		
	});
	
	$('#next2').click(function(){
				
		
		$('.qq').hide();
		$('#question3').fadeIn(30);
		
	});
	
	
	$('#back2').click(function(){
		
		$('.qq').hide();
		$('#question1').fadeIn(30);
		
	});
	
	$('#next3').click(function(){
		
		
		
		$('.qq').hide();
		$('#question4').fadeIn(30);
		
	});
	
		
	$('#back3').click(function(){
		
		$('.qq').hide();
		$('#question2').fadeIn(30);
		
	});
	
	$('#next4').click(function(){
		
	
		$('.qq').hide();
		$('#question5').fadeIn(30);
		
	});
	
	
	$('#back4').click(function(){
		
		$('.qq').hide();
		$('#question3').fadeIn(30);
		
	});
	
	$('#next5').click(function(){
		
	
		
		$('.qq').hide();
		$('#question6').fadeIn(30);
		
	});
	
	$('#back5').click(function(){
		
		$('.qq').hide();
		$('#question4').fadeIn(30);
		
	});
	
	$('#next6').click(function(){

		$('.qq').hide();
		$('#question7').fadeIn(30);
		
	});
	
	$('#back6').click(function(){
		
		$('.qq').hide();
		$('#question5').fadeIn(30);
		
	});
	
	
	
	$('#sect2').click(function(){
		
				
		$('.qq').hide();
		$('#section2').fadeIn(30);
		
	});
		
	$('#back7').click(function(){
		
		$('.qq').hide();
		$('#question6').fadeIn(30);
		
	});
	
	
	$('#next7').click(function(){
		
	
		$('.qq').hide();
		$('#question8').fadeIn(30);
		
	});
	
	
	
	$('#back8').click(function(){
		
		$('.qq').hide();
		$('#question7').fadeIn(30);
		
	});
	
	
	
	$('#sect22').click(function(){
		
				
		$('.qq').hide();
		$('#section2').fadeIn(30);
		
	});
	
	$('#next8').click(function(){
		
	
		$('.qq').hide();
		$('#question9').fadeIn(30);
		
	});
	
	
	$('#back9').click(function(){
		
		$('.qq').hide();
		$('#question8').fadeIn(30);
		
	});
	
	$('#next9').click(function(){
		
		
		$('.qq').hide();
		$('#question10').fadeIn(30);
		
	});
		
	$('#back10').click(function(){
		
		$('.qq').hide();
		$('#question9').fadeIn(30);
		
	});
	
	$('#next10').click(function(){
	
		$('.qq').hide();
		$('#instr1').fadeIn(30);
		
	});
	
	
	$('#back11').click(function(){
		
		$('.qq').hide();
		$('#question10').fadeIn(30);
		
	});
	
	
	$('#innext').click(function(){
		
		$('.qq').hide();
		$('#question11').fadeIn(30);
		
	});
	
	$('#sec11').click(function(){
		$('.qq').hide();
		$('#instr1').fadeIn(30);
	})
	
	$('#next11').click(function(){
	
		
		$('.qq').hide();
		$('#question12').fadeIn(30);
		
	});
	
	$('#back12').click(function(){
		
		$('.qq').hide();
		$('#question11').fadeIn(30);
		
	});
	
	$('#next12').click(function(){
		
	
		
		$('.qq').hide();
		$('#question13').fadeIn(30);
		
	});
	
	
	$('#back13').click(function(){
		
		$('.qq').hide();
		$('#question12').fadeIn(30);
		
	});
	
	$('#next13').click(function(){
	
		$('.qq').hide();
		$('#question14').fadeIn(30);
		
	});
	
	$('#back14').click(function(){
		
		$('.qq').hide();
		$('#question13').fadeIn(30);
		
	});
	
	$('#sect3').click(function(){
		$('.qq').hide();
		$('#section3').fadeIn(30);
	})
	
	$('#sectreturn').click(function(){
		
		$('.qq').hide();
		$('#question14').fadeIn(30);
	})
	
	$('#next14').click(function(){
	
		$('.qq').hide();
		$('#question15').fadeIn(30);
		
	});
	
	$('#next15').click(function(){
	
		$('.qq').hide();
		$('#question16').fadeIn(30);
		
	});
	
	$('#next16').click(function(){
	
		$('.qq').hide();
		$('#question17').fadeIn(30);
		
	});
	
	$('#next17').click(function(){
	
		$('.qq').hide();
		$('#question18').fadeIn(30);
		
	});
	
	$('#next18').click(function(){
	
		
		$('.qq').hide();
		$('#question19').fadeIn(30);
		
	});
	
	$('#next19').click(function(){
	
		$('.qq').hide();
		$('#question20').fadeIn(30);
		
	});
	
	$('#next20').click(function(){
	
		$('.qq').hide();
		$('#questionend').fadeIn(30);
		
	});
	
	$('#back15').click(function(){
		
		
		$('.qq').hide();
		$('#section3').fadeIn(30);
		
	});
	
	$('#back16').click(function(){
		
		$('.qq').hide();
		$('#question15').fadeIn(30);
		
	});
	
	$('#back17').click(function(){
		
		$('.qq').hide();
		$('#question16').fadeIn(30);
		
	});
	
	$('#back18').click(function(){
		
		$('.qq').hide();
		$('#question17').fadeIn(30);
		
	});
	
	$('#back19').click(function(){
		
		$('.qq').hide();
		$('#question18').fadeIn(30);
		
	});
	
	$('#back20').click(function(){
		
		$('.qq').hide();
		$('#question19').fadeIn(30);
		
	});
	
});
